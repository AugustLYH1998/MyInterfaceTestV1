# 请求封装;统一发送请求
import requests
import os

req = requests.session()

# 请求行为
def all_req(**args):
    return req.request(**args)

# 获取yaml路径
def get_yaml_path(path):
    return os.path.join(os.path.dirname(__file__), f'..\{path}')


# 获取yaml配置项
def get_conf(yaml_conf):
    conf = {
        'url': yaml_conf['request']['url'],
        'method': yaml_conf['request']['method']
    }
    if yaml_conf['request']['params']:
        conf['params'] = yaml_conf['request']['params']
        return conf
    elif yaml_conf['request']['files']:
        conf['params'] = yaml_conf['request']['files']
        return conf

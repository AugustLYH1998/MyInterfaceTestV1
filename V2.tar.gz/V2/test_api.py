
import pytest
import os
from utils.yaml_utils import write_yaml, read_yaml, read_testcase
from utils.request_utils import get_yaml_path, all_req, get_conf

class TestApi:
    # ==============获取token==============
    yaml_path = get_yaml_path('yaml_conf\\test_get_token.yaml')
    @pytest.mark.packagetest
    @pytest.mark.parametrize('yaml_conf', read_testcase(yaml_path))
    def test_gettoken(self, yaml_conf):

        url = get_conf(yaml_conf)['url']
        method = get_conf(yaml_conf)['method']
        params = get_conf(yaml_conf)['params']

        response = all_req(url=url, method=method, params=params)
        print(response.text)

        datas = {
            'access_token': response.json()['access_token']
        }
        write_yaml(datas)

    # ==============读取token==============
    yaml_path2 = get_yaml_path('yaml_conf\\test_read_token.yaml')
    @pytest.mark.packagetest
    @pytest.mark.parametrize('yaml_conf', read_testcase(yaml_path2))
    def test_get(self, yaml_conf):

        url = get_conf(yaml_conf)['url']
        method = get_conf(yaml_conf)['method']
        params = get_conf(yaml_conf)['params']

        for k, v in params.items():
            params[k] = read_yaml(k)
            params[v] = read_yaml(v)
        print(params)
        response = all_req(url=url, method=method, params=params)
        print('response:', response.text)

    # ==============文件上传==============
    yaml_path3 = get_yaml_path('yaml_conf\\test_uploadfiles.yaml')
    @pytest.mark.packagetest
    @pytest.mark.parametrize('yaml_conf', read_testcase(yaml_path3))
    def test_file(self, yaml_conf):

        url = get_conf(yaml_conf)['url']
        method = get_conf(yaml_conf)['method']
        params = get_conf(yaml_conf)['params']
        for k, v in params.items():
            params[k] = open(params['media'], 'rb')

        response = all_req(url=url, method=method, files=params)
        print(response.text)
